-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hts
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `injury_types`
--

DROP TABLE IF EXISTS `injury_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `injury_types` (
  `injury_type` tinyint NOT NULL,
  `injury_desc` text NOT NULL,
  PRIMARY KEY (`injury_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `injury_types`
--

LOCK TABLES `injury_types` WRITE;
/*!40000 ALTER TABLE `injury_types` DISABLE KEYS */;
INSERT INTO `injury_types` VALUES (1,'Head'),(2,'Heart'),(3,'Lung'),(4,'Neck'),(5,'Hand or Leg'),(6,'Any Type of Bones'),(7,'Stomach'),(8,'Burn or Cut');
/*!40000 ALTER TABLE `injury_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patients` (
  `patient_id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `age` tinyint NOT NULL,
  `created_by` smallint DEFAULT NULL,
  `modified_by` smallint DEFAULT NULL,
  PRIMARY KEY (`patient_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES (1,'Test',50,NULL,NULL),(2,'Test2',51,NULL,NULL),(3,'Test3',52,NULL,NULL),(4,'Test3',52,NULL,NULL),(5,'Test3',52,NULL,NULL),(6,'Test3',52,NULL,NULL),(7,'Test3',52,NULL,NULL);
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `triage`
--

DROP TABLE IF EXISTS `triage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `triage` (
  `triage_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NOT NULL,
  `triage_date` datetime NOT NULL,
  `injury_type` tinyint NOT NULL,
  `urgency_level` tinyint NOT NULL,
  `wait_time` smallint NOT NULL,
  `addl_comments` text,
  `created_by` smallint DEFAULT NULL,
  `modified_by` smallint DEFAULT NULL,
  PRIMARY KEY (`triage_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `triage`
--

LOCK TABLES `triage` WRITE;
/*!40000 ALTER TABLE `triage` DISABLE KEYS */;
INSERT INTO `triage` VALUES (1,7,'2023-12-08 12:52:32',2,1,15,'Test3',NULL,NULL);
/*!40000 ALTER TABLE `triage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `urgency_levels`
--

DROP TABLE IF EXISTS `urgency_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `urgency_levels` (
  `urgency_level` tinyint unsigned NOT NULL,
  `urgency_level_desc` text NOT NULL,
  `default_wait_time` smallint unsigned NOT NULL,
  PRIMARY KEY (`urgency_level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `urgency_levels`
--

LOCK TABLES `urgency_levels` WRITE;
/*!40000 ALTER TABLE `urgency_levels` DISABLE KEYS */;
INSERT INTO `urgency_levels` VALUES (1,'Immediate life-saving intervention required',0),(2,'High-risk situation/emergent',15),(3,'Urgent/stable, requiring several resources',60),(4,'Less urgent/stable, requiring only one resource',120),(5,'Non-urgent/stable, not requiring resources',180);
/*!40000 ALTER TABLE `urgency_levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` smallint NOT NULL,
  `user_code` varchar(8) NOT NULL,
  `user_pin` char(3) NOT NULL,
  `full_privs` char(1) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_code_UNIQUE` (`user_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'aantochi','123','N'),(2,'hmubarak','123','N'),(3,'buntongn','123','N'),(4,'admin','123','Y');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-08 17:43:15
